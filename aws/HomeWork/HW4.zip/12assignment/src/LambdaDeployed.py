import json
import boto3
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)

def lambda_handler(event):
    try:
        widget_request = event

        if validate_widget_request(widget_request):
            logging.info("Validation Successful")
            place_in_request_queue(widget_request)
            return {
                'statusCode': 200,
                'body': json.dumps('Request processed successfully')
            }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid Widget Request')
            }

    except Exception as e:
        logging.error(f'Error processing request: {str(e)}')
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error processing request: {str(e)}')
        }


def validate_widget_request(widget_request):
    try:
        widget_request = str(widget_request).replace("'", "\"")
        widget_request = json.loads(widget_request)
        widget_type = widget_request['type']
        logging.info(f"Validating {widget_type}")

        create_required_fields = ['requestId', 'widgetId', 'owner', 'label', 'description', 'otherAttributes']
        delete_required_fields = ['requestId', 'widgetId', 'owner']
        update_required_fields = ['requestId', 'widgetId', 'owner', 'description', 'otherAttributes']

        if widget_type == 'create':
            if all(field in widget_request for field in create_required_fields):
                return True
            else:
                logging.error("Create Request Validation Failed: Missing required fields")
                return False
        elif widget_type == 'delete':
            if all(field in widget_request for field in delete_required_fields):
                return True
            else:
                logging.error("Delete Request Validation Failed: Missing required fields")
                return False
        elif widget_type == 'update':
            if all(field in widget_request for field in update_required_fields):
                return True
            else:
                logging.error("Update Request Validation Failed: Missing required fields")
                return False
        else:
            logging.error("Validation Failed: Invalid Widget Type")
            return False
    except Exception as e:
        logging.error("Validation Failed")
        logging.error(e)
        return False 


def place_in_request_queue(widget_request, sqs_queue_url="https://sqs.us-east-1.amazonaws.com/850320733371/cs5260-requests"):
    logging.info("Placing in request queue: %s", widget_request)
    sqs = boto3.client('sqs')
    widget_request_str = json.dumps(widget_request)
    try: 
        response = sqs.send_message(
            QueueUrl=sqs_queue_url,
            MessageBody=widget_request_str
        )
        logging.info("Widget Request placed in the SQS queue. Message ID: %s", response['MessageId'])
        return True
    except Exception as e:
        logging.error(f"Error placing Widget Request in SQS queue: {str(e)}")
        return False
    pass
